package lab1.command;

public interface Command {
    void execute();
    void undo();
}